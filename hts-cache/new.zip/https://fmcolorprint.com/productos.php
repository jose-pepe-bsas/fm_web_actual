<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="bolsas publicitarias, fmcolorprint, zona oeste, haedo, buenos aires">

    <title> FMColorprint | Creatividad en bolsas publicitarias | Productos </title>

    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/carousel.css" rel="stylesheet">
    <link href="css/sticky-footer-navbar.css" rel="stylesheet">
    <link rel="icon" href="img/fmcolorprinticono.png">
	<link rel="stylesheet" href="css/fontawesome-all.min.css">
</head>

    <body>

    <!-- modals -->
    <div id="manija-rinon" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="manijaRinon">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h3 id="manijaRinon" class="modal-title h4-fmcolorprint">Bolsa tubular troquel manija riñón</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="col-lg-4 thumbnail"><img class="img-responsive" src="img/productos/manija_rinon/belle.png"></div>
                            <div class="col-lg-4 thumbnail"> <img class="img-responsive" src="img/productos/manija_rinon/tabaco.png"></div>
                            <div class="col-lg-4 thumbnail"><img class="img-responsive" src="img/productos/manija_rinon/oneill.png"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="rinon" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title h4-fmcolorprint">Bolsa tubular troquel riñón</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/rinon/alma.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/rinon/atac.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/rinon/newmar.png"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="redondo" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title h4-fmcolorprint">Bolsa tubular troquel redondo</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/redondo/buon.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/redondo/malucos.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/redondo/moto.png"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="asa" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title h4-fmcolorprint">Bolsa tubular troquel asa</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/asa/sitevisto.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/asa/botanico.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/asa/prana.png"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="asa-flexible" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title h4-fmcolorprint">Bolsa tubular troquel asa flexible</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/asa_flexible/prana.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/asa_flexible/computacion.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/asa_flexible/almalepik.png"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="cartera" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title h4-fmcolorprint">Bolsa tubular troquel tipo cartera</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/cartera/kapsol.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/cartera/xenobia.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/cartera/wallstreet.png"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="camiseta" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title h4-fmcolorprint">Bolsa camiseta</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/camiseta/automundo.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/camiseta/jasa.png"></div>
                            <div class="thumbnail col-lg-4"><img class="img-responsive" src="img/productos/camiseta/moto.png"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="sobre" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title h4-fmcolorprint">Bolsa sobre</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="thumbnail col-lg-6"><img height="500" src="img/productos/sobre_solapa/paris.png"></div>
                            <div class="thumbnail col-lg-6"><img height="500" src="img/productos/sobre_solapa/world.png"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="sobre-solapa" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h3 class="modal-title h4-fmcolorprint">Bolsa sobre con solapa</h3>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="thumbnail col-lg-6"><img height="500" src="img/productos/sobre_solapa/paris.png"></div>
                            <div class="thumbnail col-lg-6"><img height="500" src="img/productos/sobre_solapa/world.png"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- fin modals -->

        <div class="navbar-wrapper">
            <div class="container">
                <nav class="navbar navbar-fmcolorprint navbar-fixed-top">
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand-fmcolorprint logo-container" href="index.php">
                                <div class="visible-sm visible-xs">
                                    <img class="logo-sm" width="200" src="img/LOGO.png"/>
                                </div>
                                <div class="visible-md visible-lg-inline">
                                    <img style="padding-top: 5px;" class="img-responsive" width="250" src="img/LOGO.png"/>
                                </div>
                            </a>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav pull-right">
                                <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
                                <li><a href="materiales.php"><span class="glyphicon glyphicon-leaf"></span> Materiales</a></li>
                                <li class="active"><a href="productos.php"><span class="glyphicon glyphicon-shopping-cart"></span> Productos</a></li>
                                <li><a href="cotizaciones.php"><span class="glyphicon glyphicon-phone-alt"></span> Cotizaciones</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>

        <div style="margin-top:65px;">
            <img src="img/productos/banner.png" style="margin:auto" class="img-responsive img-rounded" alt="Productos FMColorprint"/>
        </div>

        <div class="container marketing" style="padding-top:0px; margin-bottom: 50px;">
            <div class="page-header-fmcolorprint">
                <h1>Nuestros productos</h1>
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-6 col-xs-12">
                    <div class="thumbnail-fmcolorprint">
                        <div class="caption">
                            <h3 class="h3-fmcolorprint">
                                Bolsa tubular troquel manija riñon
                                <small>
                                    <button class="btn btn-default btn-xs" data-toggle="modal" data-target="#manija-rinon">
                                        Ver productos
                                    </button>
                                </small>
                            </h3>
                            <ul>
                                <li>Troquelada sobre el mismo material</li>
                                <li>Polietileno de alta/baja densidad</li>
                                <li>Blanco, color o cristal</li>
                                <li>Impresa hasta 4 colores</li>
                            </ul>
                        </div>
                        <div class="thumbnail">
                            <img class="img-responsive" src="img/productos/manija_rinon/medidas.png">
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-xs-12">
                    <div class="thumbnail-fmcolorprint">
                        <div class="caption">
                            <h3 class="h3-fmcolorprint">
                                Bolsa tubular troquel riñon
                                <small>
                                    <button class="btn btn-default btn-xs" data-toggle="modal" data-target="#rinon">
                                        Ver productos
                                    </button>
                                </small>
                            </h3>
                            <ul>
                                <li>Troquelada sobre el mismo material</li>
                                <li>Polietileno de alta/baja densidad</li>
                                <li>Blanco, color o cristal</li>
                                <li>Impresa hasta 4 colores</li>
                            </ul>
                        </div>
                        <div class="thumbnail">
                            <img class="img-responsive" src="img/productos/rinon/medidas.png">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-6 col-xs-12">
                    <div class="thumbnail-fmcolorprint">
                        <div class="caption">
                            <h3 class="h3-fmcolorprint">
                                Bolsa tubular troquel redondo
                                <small>
                                    <button class="btn btn-default btn-xs" data-toggle="modal" data-target="#redondo">
                                        Ver productos
                                    </button>
                                </small>
                            </h3>
                            <ul>
                                <li>Troquelada sobre el mismo material</li>
                                <li>Polietileno de alta/baja densidad</li>
                                <li>Blanco, color o cristal</li>
                                <li>Impresa hasta 4 colores</li>
                            </ul>
                        </div>
                        <div class="thumbnail">
                            <img class="img-responsive" src="img/productos/redondo/medidas.png">
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-xs-12">
                    <div class="thumbnail-fmcolorprint">
                        <div class="caption">
                            <h3 class="h3-fmcolorprint">
                                Bolsa tubular troquel asa
                                <small>
                                    <button class="btn btn-default btn-xs" data-toggle="modal" data-target="#asa">
                                        Ver productos
                                    </button>
                                </small>
                            </h3>
                            <ul>
                                <li>Troquelada sobre el mismo material</li>
                                <li>Polietileno de alta/baja densidad</li>
                                <li>Blanco, color o cristal</li>
                                <li>Impresa hasta 4 colores</li>
                            </ul>
                        </div>
                        <div class="thumbnail">
                            <img class="img-responsive" src="img/productos/asa/medidas.png">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-6 col-xs-12">
                    <div class="thumbnail-fmcolorprint">
                        <div class="caption">
                            <h3 class="h3-fmcolorprint">
                                Bolsa tubular con asa flexible
                                <small>
                                    <button class="btn btn-default btn-xs" data-toggle="modal" data-target="#asa-flexible">
                                        Ver productos
                                    </button>
                                </small>
                            </h3>
                            <ul>
                                <li>Manijas flexibles (mismo material) soldadas</li>
                                <li>Polietileno de alta/baja densidad</li>
                                <li>Blanco, color o cristal</li>
                                <li>Impresa hasta 4 colores</li>
                            </ul>
                        </div>
                        <div class="thumbnail">
                            <img class="img-responsive" src="img/productos/asa_flexible/medidas.png">
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-xs-12">
                    <div class="thumbnail-fmcolorprint">
                        <div class="caption">
                            <h3 class="h3-fmcolorprint">
                                Bolsa tubular con troquel tipo cartera
                                <small>
                                    <button class="btn btn-default btn-xs" data-toggle="modal" data-target="#cartera">
                                        Ver productos
                                    </button>
                                </small>
                            </h3>
                            <ul>
                                <li>Troquelada sobre el mismo material</li>
                                <li>Polietileno de alta/baja densidad</li>
                                <li>Blanco, color o cristal</li>
                                <li>Impresa hasta 4 colores</li>
                            </ul>
                        </div>
                        <div class="thumbnail">
                            <img class="img-responsive" src="img/productos/cartera/medidas.png">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-6 col-xs-12">
                    <div class="thumbnail-fmcolorprint">
                        <div class="caption">
                            <h3 class="h3-fmcolorprint">
                                Bolsa camiseta
                                <small>
                                    <button class="btn btn-default btn-xs" data-toggle="modal" data-target="#camiseta">
                                        Ver productos
                                    </button>
                                </small>
                            </h3>
                            <ul>
                                <li>Fuelles laterales que forman manijas</li>
                                <li>Troquelada sobre el mismo material</li>
                                <li>Polietileno de alta/baja densidad</li>
                                <li>Blanco, color o cristal</li>
                                <li>Impresa hasta 4 colores</li>
                            </ul>
                        </div>
                        <div class="thumbnail">
                            <img class="img-responsive" src="img/productos/camiseta/medidas.png">
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-xs-12">
                    <div class="thumbnail-fmcolorprint">
                        <div class="caption">
                            <h3 class="h3-fmcolorprint">
                                Bolsa sobre
                                <small>
                                    <button class="btn btn-default btn-xs" data-toggle="modal" data-target="#sobre">
                                        Ver productos
                                    </button>
                                </small>
                            </h3>
                            <ul>
                                <li>Polipropileno o polietileno de alta/baja densidad</li>
                                <li>Blanco, color o cristal</li>
                                <li>Impresa hasta 4 colores</li>
                                <li class="list-unstyled">&nbsp;</li>
                                <li class="list-unstyled">&nbsp;</li>
                            </ul>
                        </div>
                        <div class="thumbnail">
                            <img class="img-responsive" src="img/productos/sobre/medidas.png">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6 col-md-6 col-xs-12">
                    <div class="thumbnail-fmcolorprint">
                        <div class="caption">
                            <h3 class="h3-fmcolorprint">
                                Bolsa sobre con solapa
                                <small>
                                    <button class="btn btn-default btn-xs" data-toggle="modal" data-target="#sobre-solapa">
                                        Ver productos
                                    </button>
                                </small>
                            </h3>
                            <ul>
                                <li>Con/sin adhesivo repegable</li>
                                <li>Polipropileno o polietileno de alta/baja densidad</li>
                                <li>Blanco, color o cristal</li>
                                <li>Impresa hasta 4 colores</li>
                            </ul>
                        </div>
                        <div class="thumbnail">
                            <img class="img-responsive" src="img/productos/sobre_solapa/medidas.png">
                        </div>
                    </div>
                </div>
                <div class="col-sm-6 col-md-6 col-xs-12">
                    <div class="thumbnail-fmcolorprint">
                        <div class="caption">
                            <h3 class="h3-fmcolorprint">
                                Rollos
                            </h3>
                            <ul>
                                <li>En bobinas a partir de 10cm</li>
                                <li>Polietileno de alta/baja densidad</li>
                                <li>Blanco, color o cristal</li>
                                <li>Impresa hasta 4 colores</li>
                            </ul>
                        </div>
                        <div class="thumbnail">
                            <img class="img-responsive" src="img/productos/rollos/medidas.png">
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-sm-12">
                        <p class="text-muted">
                            &copy; 2016 FMColorprint
                        </p>
                        <p class="text-muted">
                            Haedo &middot; Buenos Aires &middot; Argentina
                        </p>
                    </div>
                    <div class="col-lg-6 col-sm-12">
                        <p class="text-muted">
                            <i class="fa fa-envelope"></i> info@fmcolorprint.com | fmcolorprint@gmail.com |
                            <i class="fa fa-phone"></i> 11 2201 2062 |
                            <i class="fab fa-whatsapp"></i> 11 3293 5668
                        </p>
                        <p class="text-muted">
                            Buscanos también en: 
                            <a style="font-size: 150%;" href="https://instagram.com/fmcolorprint" target="_blank">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a style="font-size: 150%;" href="https://facebook.com/fmcolorprint" target="_blank">
                                <i class="fab fa-facebook-square"></i>
                            </a>
                            <a href="https://perfil.mercadolibre.com.ar/FMCOLORPRINT.COM" target="_blank">
                                <img style="display: inline; margin-top: -6px;" class="img-responsive" src="img/logo__large_plus.png" width="75px"/>
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script src="js/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/jquery.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/ie10-viewport-bug-workaround.js"></script>

    </body>

</html>
