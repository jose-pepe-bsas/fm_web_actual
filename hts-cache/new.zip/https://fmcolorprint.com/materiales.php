<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="bolsas publicitarias, fmcolorprint, zona oeste, haedo, buenos aires">

    <title> FMColorprint | Creatividad en bolsas publicitarias | Materiales </title>

    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/carousel.css" rel="stylesheet">
    <link href="css/sticky-footer-navbar.css" rel="stylesheet">
    <link rel="icon" href="img/fmcolorprinticono.png">
	<link rel="stylesheet" href="css/fontawesome-all.min.css">
</head>

    <body>
        <div class="navbar-wrapper">
            <div class="container">
                <nav class="navbar navbar-fmcolorprint navbar-fixed-top">
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand-fmcolorprint logo-container" href="index.php">
                                <div class="visible-sm visible-xs">
                                    <img class="logo-sm" width="200" src="img/LOGO.png"/>
                                </div>
                                <div class="visible-md visible-lg-inline">
                                    <img style="padding-top: 5px;" class="img-responsive" width="250" src="img/LOGO.png"/>
                                </div>
                            </a>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav pull-right">
                                <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
                                <li class="active"><a href="materiales.php"><span class="glyphicon glyphicon-leaf"></span> Materiales</a></li>
                                <li><a href="productos.php"><span class="glyphicon glyphicon-shopping-cart"></span> Productos</a></li>
                                <li><a href="cotizaciones.php"><span class="glyphicon glyphicon-phone-alt"></span> Cotizaciones</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>

        <div style="margin-top:65px;">
            <img src="img/materiales/banner.png" style="margin:auto" class="img-responsive img-rounded" alt="Materiales FMColorprint"/>
        </div>

        <div class="container" style="padding-top:0px; margin-bottom: 50px;">
            <div class="page-header-fmcolorprint">
                <h1>Materiales</h1>
            </div>
            <div class="row">
                <div class="col-lg-4 material">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 align="center" class="h2-fmcolorprint">
                                Polietileno alta densidad <br/>
                                (PEAD)
                            </h2>
                            <p class="materiales" align="justify">
                                <i style="color:#4cae4c" class="glyphicon glyphicon-bookmark"></i>
                                El Polietileno de Alta Densidad es un termoplástico fabricado a
                                partir del Etileno (elaborado a partir del etano, uno de los
                                componentes del gas natural). Es muy versátil y se lo puede
                                transformar de diversas formas.
                            </p>
                        </div>
                    </div>
                    <div class="row hidden-lg">
                        <div class="col-lg-12">
                            <div class="row">
                                <h3>
                                    <i style="color:#4cae4c" class="glyphicon glyphicon-check"></i> Ventajas y beneficios:
                                </h3>
                                <div>
                                    <div class="panel-body">
                                        <ul class="list-group">
                                            <li class="list-group-item">
                                                <h4>
                                                    <i class="glyphicon glyphicon-pushpin"></i> Resistente a las bajas temperaturas
                                                </h4>
                                            </li>
                                            <li class="list-group-item">
                                                <h4>
                                                    <i class="glyphicon glyphicon-pushpin"></i> Liviano
                                                </h4>
                                            </li>
                                            <li class="list-group-item">
                                                <h4>
                                                    <i class="glyphicon glyphicon-pushpin"></i> Impermeable
                                                </h4>
                                            </li>
                                            <li class="list-group-item">
                                                <h4>
                                                    <i class="glyphicon glyphicon-pushpin"></i> Inerte al contenido
                                                </h4>
                                            </li>
                                            <li class="list-group-item">
                                                <h4>
                                                    <i class="glyphicon glyphicon-pushpin"></i> No tóxico
                                                </h4>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 material">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 align="center" class="h2-fmcolorprint">
                                Polietileno baja densidad <br/>
                                (PEBD)
                            </h2>
                            <p class="materiales" align="justify">
                                <i style="color:#4cae4c" class="glyphicon glyphicon-bookmark"></i>
                                Se produce a partir del gas natural. Al igual que el PEAD,
                                es de gran versatilidad y se procesa de diversas formas.
                            </p>
                        </div>
                    </div>
                    <div class="row hidden-lg">
                        <div class="col-lg-12">
                            <div class="row">
                                <h3>
                                    <i style="color:#4cae4c" class="glyphicon glyphicon-check"></i> Ventajas y beneficios:
                                </h3>
                                <div>
                                    <div class="panel-body">
                                        <ul class="list-group">
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> No tóxico</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Flexible</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Liviano</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Transparente</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Inerte</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Impermeable</h4></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 material">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 align="center" class="h2-fmcolorprint">
                                Polipropileno <br/>
                                (PP)
                            </h2>
                            <p class="materiales" align="justify">
                                <i style="color:#4cae4c" class="glyphicon glyphicon-bookmark"></i>
                                Los copolímeros se forman agregando Etileno durante el proceso. El PP es
                                el termoplástico de más baja densidad. Es un plástico de elevada rigidez,
                                alta cristalinidad, elevado punto de fusión y excelente resistencia química.
                                Al adicionarle distintas cargas (talco, caucho, fibra de vidrio, etc.)
                                se potencian sus propiedades hasta transformarlo en un polímero de ingeniería.
                                El PP es transformado en la industria por los procesos de inyección, soplado,
                                extrusión y termoformado.
                            </p>
                        </div>
                    </div>
                    <div class="row hidden-lg">
                        <div class="col-lg-12">
                            <div class="row">
                                <h3>
                                    <i style="color:#4cae4c" class="glyphicon glyphicon-check"></i> Ventajas y beneficios:
                                </h3>
                                <div>
                                    <div class="panel-body">
                                        <ul class="list-group">
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Inerte (al contenido)</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Resistente a la temperatura (hasta 135°)</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Barrera a los aromas</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Impermeable</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Brillo</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Liviano</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Transparente en películas</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> No tóxico</h4></li>
                                            <li class="list-group-item"><h4><i class="glyphicon glyphicon-pushpin"></i> Alta resistencia química</h4></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row visible-lg">
                <div class="table-responsive">
                    <table class="table table-hover table-condensed">
                        <thead>
                            <tr>
                                <th class="col-lg-3">Ventajas y beneficios</th>
                                <th class="col-lg-3">PEAD</th>
                                <th class="col-lg-3">PEBD</th>
                                <th class="col-lg-3">PP</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> No tóxico</td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Flexible</td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Liviano</td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Transparente</td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Inerte (al contenido)</td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Impermeable</td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Resistente a bajas temperaturas</td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Resistente a la temperatura (hasta 135°C)</td>
                                <td style="vertical-align:middle;" class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td style="vertical-align:middle;" class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td style="vertical-align:middle;" class="success"><i class="glyphicon glyphicon-ok"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Barrera a los aromas</td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Brillo</td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Transparente en películas</td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                            </tr>
                            <tr>
                                <td><i class="glyphicon glyphicon-pushpin"></i> Alta resistencia química</td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="danger"><i class="glyphicon glyphicon-remove"></i></td>
                                <td class="success"><i class="glyphicon glyphicon-ok"></i></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-sm-12">
                        <p class="text-muted">
                            &copy; 2016 FMColorprint
                        </p>
                        <p class="text-muted">
                            Haedo &middot; Buenos Aires &middot; Argentina
                        </p>
                    </div>
                    <div class="col-lg-6 col-sm-12">
                        <p class="text-muted">
                            <i class="fa fa-envelope"></i> info@fmcolorprint.com | fmcolorprint@gmail.com |
                            <i class="fa fa-phone"></i> 11 2201 2062 |
                            <i class="fab fa-whatsapp"></i> 11 3293 5668
                        </p>
                        <p class="text-muted">
                            Buscanos también en: 
                            <a style="font-size: 150%;" href="https://instagram.com/fmcolorprint" target="_blank">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a style="font-size: 150%;" href="https://facebook.com/fmcolorprint" target="_blank">
                                <i class="fab fa-facebook-square"></i>
                            </a>
                            <a href="https://perfil.mercadolibre.com.ar/FMCOLORPRINT.COM" target="_blank">
                                <img style="display: inline; margin-top: -6px;" class="img-responsive" src="img/logo__large_plus.png" width="75px"/>
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script src="js/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/jquery.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/ie10-viewport-bug-workaround.js"></script>

    </body>
</html>
