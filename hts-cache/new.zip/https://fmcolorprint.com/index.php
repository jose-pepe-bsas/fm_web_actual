<!DOCTYPE html>
<html lang="es">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="bolsas publicitarias, fmcolorprint, zona oeste, haedo, buenos aires">

        <title> FMColorprint | Creatividad en bolsas publicitarias | Home </title>

        <link href="css/bootstrap.css" rel="stylesheet">
        <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
        <link href="css/carousel.css" rel="stylesheet">
        <link href="css/sticky-footer-navbar.css" rel="stylesheet">
        <link rel="icon" href="img/fmcolorprinticono.png">
		<link rel="stylesheet" href="css/fontawesome-all.min.css">
    </head>

    <body>
        <div class="navbar-wrapper">
            <div class="container">
                <nav class="navbar navbar-fmcolorprint navbar-fixed-top">
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand-fmcolorprint logo-container" href="index.php">
                                <div class="visible-sm visible-xs">
                                    <img class="logo-sm" width="200" src="img/LOGO.png"/>
                                </div>
                                <div class="visible-md visible-lg-inline">
                                    <img style="padding-top: 5px;" class="img-responsive" width="250" src="img/LOGO.png"/>
                                </div>
                            </a>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav pull-right">
                                <li class="active"><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
                                <li><a href="materiales.php"><span class="glyphicon glyphicon-leaf"></span> Materiales</a></li>
                                <li><a href="productos.php"><span class="glyphicon glyphicon-shopping-cart"></span> Productos</a></li>
                                <li><a href="cotizaciones.php"><span class="glyphicon glyphicon-phone-alt"></span> Cotizaciones</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>

        <div style="margin-top:65px;">
            <img src="img/index/banner.png" style="margin:auto" class="img-responsive img-rounded" alt="FMColorprint | Bolsas publicitarias | Home"/>
        </div>
        <div class="container marketing"  style="padding-top:0px; margin-bottom: 50px;">
            <div class="page-header-fmcolorprint">
                <h1> </h1>
            </div>
            <div class="row">
                <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                    <img class="img-circle" width="200" src="img/index/trayectoria.png" alt="Trayectoria">
                    <h2 class="h2-fmcolorprint">Trayectoria</h2>
                    <p>Empresa con más de 25 años de trayectoria en la industria,
                        FMColorprint combina en sus productos calidad, velocidad,
                        accesibilidad en los costos  y atención, priorizando los
                        intereses de nuestros clientes.
                    </p>
                </div>
                <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                    <img class="img-circle" width="200" src="img/index/politica.png" alt="Color">
                    <h2 class="h2-fmcolorprint">Política</h2>
                    <p>Brindar una atención y trato amable y cordial a todos nuestros clientes, 
                        proponer soluciones integrales y alcanzar resultados que cumplan e
                        incluso superen las expectativas.
                    </p>
                </div>
                <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                    <img class="img-circle" width="200" src="img/index/mision.png" alt="Misión">
                    <h2 class="h2-fmcolorprint">Misión</h2>
                    <p>Ofrecer diferentes alternativas en la fabricación y confeccion de bolsas
                        plásticas, Asesoramiento para lograr el mejor diseño para presentación
                        de su producto sin descuidar los costos, con la mejor calidad, y plazos
                        de entrega mas breves, con la finalidad de complacer las exigencias de
                        nuestros clientes, mediando servicio y atención personalizada.
                    </p>
                </div>
                <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                    <img class="img-circle" width="200" src="img/index/calidad.png" alt="Calidad">
                    <h2 class="h2-fmcolorprint">Calidad</h2>
                    <p>Confeccionamos y estampamos todo tipo de bolsas en diferentes formas y tamaños
                        Bolsas de polietileno de baja, alta densidad y Poliprolipeno; con troquel riñón,
                        tipo camiseta, con asa flexible, tipo cartera, bobinas, trabajos especiales,
                        que mejor se adapten a su necesidad.
                        Contamos con maquinaria adecuada para realizar todos los trabajos,
                        respondiendo con eficacia, a la demanda de nuestros clientes.
                    </p>
                </div>
                <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                    <img class="img-circle" width="200" src="img/index/diseno.png" alt="Diseño">
                    <h2 class="h2-fmcolorprint">Diseño</h2>
                    <p>La bolsa es su medio de publicidad trasladable, personalícelas con su logo,
                        marca, servicios, productos, eventos, etc. Para que nuestros productos se
                        distingan, contamos con nuestro departamento de diseño, y un equipo de
                        creativos capaces de ofrecer la mejor instrucción al momento de elegir su bolsa.
                    </p>
                </div>
                <div class="col-lg-4 col-sm-4 col-md-4 col-xs-12">
                    <img class="img-circle" width="200" src="img/index/oxi.png" alt="Reciclables y oxibiodegradables">
                    <h2 class="h2-fmcolorprint">Reciclables y oxi-biodegradables</h2>
                    <p>Nuestros productos son 100% Reciclables y Oxi-Biodegradables.</p>
                </div>
            </div>
        </div>

        <footer class="footer">
            <div class="container">
            	<div class="row">
        			<div class="col-lg-6 col-sm-12">
        		  		<p class="text-muted">
        	                &copy; 2016 FMColorprint
        	            </p>
        				<p class="text-muted">
        					Haedo &middot; Buenos Aires &middot; Argentina
        				</p>
        			</div>
        			<div class="col-lg-6 col-sm-12">
    					<p class="text-muted">
    		                <i class="fa fa-envelope"></i> info@fmcolorprint.com | fmcolorprint@gmail.com |
    		                <i class="fa fa-phone"></i> 11 2201 2062 |
    						<i class="fab fa-whatsapp"></i> 11 3293 5668
    		    		</p>
    					<p class="text-muted">
    						Buscanos también en: 
    						<a style="font-size: 150%;" href="https://instagram.com/fmcolorprint" target="_blank">
                                <i class="fab fa-instagram"></i>
                            </a>
    						<a style="font-size: 150%;" href="https://facebook.com/fmcolorprint" target="_blank">
                                <i class="fab fa-facebook-square"></i>
                            </a>
                            <a href="https://perfil.mercadolibre.com.ar/FMCOLORPRINT.COM" target="_blank">
                                <img style="display: inline; margin-top: -6px;" class="img-responsive" src="img/logo__large_plus.png" width="75px"/>
                            </a>
    					</p>
        			</div>
            	</div>
            </div>
        </footer>
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script src="js/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/jquery.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/ie10-viewport-bug-workaround.js"></script>

    </body>

</html>
