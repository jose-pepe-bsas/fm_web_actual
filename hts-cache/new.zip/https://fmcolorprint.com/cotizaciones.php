

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="bolsas publicitarias, fmcolorprint, zona oeste, haedo, buenos aires">

    <title> FMColorprint | Creatividad en bolsas publicitarias | Cotizaciones </title>

    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/ie10-viewport-bug-workaround.css" rel="stylesheet">
    <link href="css/carousel.css" rel="stylesheet">
    <link href="css/sticky-footer-navbar.css" rel="stylesheet">
    <link rel="icon" href="img/fmcolorprinticono.png">
	<link rel="stylesheet" href="css/fontawesome-all.min.css">
</head>

    <body>
        <div class="navbar-wrapper">
            <div class="container">
                <nav class="navbar navbar-fmcolorprint navbar-fixed-top">
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand-fmcolorprint logo-container" href="index.php">
                                <div class="visible-sm visible-xs">
                                    <img class="logo-sm" width="200" src="img/LOGO.png"/>
                                </div>
                                <div class="visible-md visible-lg-inline">
                                    <img style="padding-top: 5px;" class="img-responsive" width="250" src="img/LOGO.png"/>
                                </div>
                            </a>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav pull-right">
                                <li><a href="index.php"><span class="glyphicon glyphicon-home"></span> Home</a></li>
                                <li><a href="materiales.php"><span class="glyphicon glyphicon-leaf"></span> Materiales</a></li>
                                <li><a href="productos.php"><span class="glyphicon glyphicon-shopping-cart"></span> Productos</a></li>
                                <li class="active"><a href="cotizaciones.php"><span class="glyphicon glyphicon-phone-alt"></span> Cotizaciones</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </div>

        <div style="margin-top:65px;">
            <img src="img/cotizaciones/banner.png" style="margin:auto" class="img-responsive img-rounded" alt="Cotizaciones FMColorprint"/>
        </div>

        <div class="container marketing" style="padding-top:0px; margin-bottom: 50px;">
            <div class="page-header-fmcolorprint">
                <h1>Cotizaciones</h1>
            </div>
            <div class="row">
                <form action="" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="submit">
                    <div class="panel panel-colorprint">
                        <div class="panel-heading">
                            <h4 style="text-align:center">Datos personales</h4>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-md-4 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Nombre y apellido</label><br/>
                                    <input type="text" class="form-control" name="nombre" pattern=".{5,}" title="Ingrese por lo menos cinco caracteres" required/>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Rubro del comercio</label><br/>
                                    <input type="text" class="form-control" name="rubro" pattern=".{5,}" title="Ingrese por lo menos cinco caracteres" required/>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Nombre del comercio</label><br/>
                                    <input type="text" class="form-control" name="comercio" pattern=".{3,}" title="Ingrese por lo menos tres caracteres" required/>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Ubicación (zona)</label><br/>
                                    <input type="text" class="form-control" name="ubicacion" pattern=".{5,}" title="Ingrese por lo menos cinco caracteres" required/>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Teléfono</label><br/>
                                    <input type="text" class="form-control" name="tel" pattern=".{8,}" title="Ingrese por lo menos ocho caracteres" required/>
                                </div>
                                <div class="col-md-4 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Email</label><br/>
                                    <input type="email" class="form-control" name="mail" required/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel panel-colorprint">
                        <div class="panel-heading">
                            <h4 style="text-align:center">Presupuesto</h4>
                        </div>
                        <div class="panel-body">
                            <div class="form-group">
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Ancho (cm.)</label>
                                    <input type="number" class="form-control" name="ancho" min="0" required/>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Largo (cm.)</label>
                                    <input type="number" class="form-control" name="largo" min="0" required/>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Espesor (micrones)</label>
                                    <input type="number" class="form-control" name="espesor" min="0" required/>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Cantidad aproximada</label>
                                    <input type="number" class="form-control" name="cant" min="0" required/>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Tipo de material</label><br/>
                                    <select name="tipo_material" class="form-control" required>
                                        <option value=""></option>
                                        <option value="Alta Densidad">Alta Densidad</option>
                                        <option value="Baja Densidad">Baja Densidad</option>
                                        <option value="Polipropileno">Polipropileno</option>
                                    </select>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Tipo de bolsa</label><br/>
                                    <select name="tipo_bolsa" class="form-control" required>
                                        <option value=""></option>
                                        <option value="Camiseta">Camiseta</option>
                                        <option value="De fondo común">De fondo común</option>
                                        <option value="En bobinas precortadas">En bobinas precortadas</option>
                                        <option value="Rollo">Rollo (farmacias y veterinarias)</option>
                                        <option value="Tubular sobre">Tubular sobre</option>
                                        <option value="Tubular troquel riñon">Tubular troquel riñón</option>
                                        <option value="Tubular troquel cartera">Tubular troquel cartera</option>
                                        <option value="Tubular troquel manija riñon">Tubular troquel manija riñón</option>
                                        <option value="Tubular troquel manija riñon c/punta redonda">Tubular troquel manija riñon c/ punta redonda</option>
                                        <option value="Tubular troquel redondo">Tubular troquel redondo</option>
                                        <option value="Tubular troquel asa">Tubular troquel asa</option>
                                        <option value="Tubular troquel sobre polipropileno">Tubular sobre polipropileno</option>
                                        <option value="Tubular con adhesivo">Tubular sobre polipropileno c/ solapa c/ adhesivo repegable</option>
                                        <option value="Tubular sin adhesivo">Tubular sobre polipropileno c/ solapa sin adhesivo</option>

                                    </select>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Tipo de impresión</label><br/>
                                    <select name="tipo_impr" class="form-control" required>
                                        <option value=""></option>
                                        <option value="Impresas 1 Cara 1 Color">Impresas 1 Cara 1 Color</option>
                                        <option value="Impresas 2 Caras 1 Color">Impresas 2 Caras 1 Color</option>
                                        <option value="Impresas 1 Cara 2 Colores">Impresas 1 Cara 2 Colores</option>
                                        <option value="Impresas 2 Caras 2 Colores">Impresas 2 Caras 2 Colores</option>
                                        <option value="Impresas 1 Cara 3 Colores">Impresas 1 Cara 3 Colores</option>
                                        <option value="Impresas 2 Caras 3 Colores">Impresas 2 Caras 3 Colores</option>
                                        <option value="Impresas 1 Cara 4 Colores">Impresas 1 Cara 4 Colores</option>
                                        <option value="Impresas 2 Caras 4 Colores">Impresas 2 Caras 4 Colores</option>
                                    </select>
                                </div>
                                <div class="col-md-3 col-sm-6 col-xs-12">
                                    <label class="label-fmcolorprint">Color</label><br/>
                                    <select name="color" class="form-control" required>
                                        <option value=""></option>
                                        <option value="Blanco">Blanco</option>
                                        <option value="Transparente">Transparente</option>
                                        <option value="Otro">Otro</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer-fmcolorprint">
                            <span>
                                <i class="glyphicon glyphicon-info-sign"></i>
                                A diferencia del blanco y cristal, los materiales pigmentados
                                incrementan el costo y tiempo de fabricación.
                            </span>
                        </div>
                    </div>
                    <footer>
                        <div class="col-lg-12">
                            <input type="submit" class="btn btn-success btn-success pull-right" value="Enviar consulta">
                        </div>
                    </footer>
                </form>
            </div>
        </div>

        <footer class="footer">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-sm-12">
                        <p class="text-muted">
                            &copy; 2016 FMColorprint
                        </p>
                        <p class="text-muted">
                            Haedo &middot; Buenos Aires &middot; Argentina
                        </p>
                    </div>
                    <div class="col-lg-6 col-sm-12">
                        <p class="text-muted">
                            <i class="fa fa-envelope"></i> info@fmcolorprint.com | fmcolorprint@gmail.com |
                            <i class="fa fa-phone"></i> 11 2201 2062 |
                            <i class="fab fa-whatsapp"></i> 11 3293 5668
                        </p>
                        <p class="text-muted">
                            Buscanos también en: 
                            <a style="font-size: 150%;" href="https://instagram.com/fmcolorprint" target="_blank">
                                <i class="fab fa-instagram"></i>
                            </a>
                            <a style="font-size: 150%;" href="https://facebook.com/fmcolorprint" target="_blank">
                                <i class="fab fa-facebook-square"></i>
                            </a>
                            <a href="https://perfil.mercadolibre.com.ar/FMCOLORPRINT.COM" target="_blank">
                                <img style="display: inline; margin-top: -6px;" class="img-responsive" src="img/logo__large_plus.png" width="75px"/>
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        </footer>
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script src="js/jquery.min.js"></script>
        <script>window.jQuery || document.write('<script src="js/jquery.min.js"><\/script>')</script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/ie10-viewport-bug-workaround.js"></script>

    </body>

</html>

